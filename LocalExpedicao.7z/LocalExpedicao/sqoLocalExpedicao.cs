﻿using AI1627Common20.TemplateDebugging;
using Common.Stara.LES.PickingAux.AI1450LESServiceFolhaRosto;
using sqoClassLibraryAI1151FilaProducao.Process;

namespace TemplateStara.Expedicao.LocalExpedicao
{
    [TemplateDebug("LES - Cadastro Local Expedicao")]
    public class sqoLocalExpedicao : sqoClassProcessMovimentacao
    {
        private string sParamListagem_CRT_Texto = "";

        public override sqoClassMessage Executar(string sAction
                                                , string sXmlDados
                                                , string sXmlType
                                                , List<sqoClassParametrosEstrutura> oListaParametrosMovimentacao
                                                , List<sqoClassParametrosEstrutura> oListaParametrosListagem
                                                , string sNivel
                                                , string sUsuario
                                                , object oObjAux)
        {
            sqoClassMessage oClassMessage = new sqoClassMessage();


            GetParametrosListagem(oListaParametrosListagem);

            try
            {
                if (sAction == "Importar")
                {
                    List<sqoClassPcpDynCriteriaItem> oListPersistencia = new List<sqoClassPcpDynCriteriaItem>();

                    oListPersistencia = ProcessXLSX(oListaParametrosMovimentacao, sNivel);

                    oDBconnection.Open();

                    int nRegistro = -1;

                    try
                    {
                        sqoClassBiblioDB.BeginTransaction(oDBconnection);

                        nRegistro = 1;

                        foreach (sqoClassPcpDynCriteriaItem oItem in oListPersistencia)
                        {
                            if (oItem.Acao == "ADICIONAR")
                            {
                                this.ValidaPersistencia(oDBconnection, oItem, oItem.Acao);
                                this.Adicionar(oDBconnection, oItem, sUsuario);
                            }
                            else if (oItem.Acao == "EDITAR")
                            {
                                this.ValidaPersistencia(oDBconnection, oItem, oItem.Acao);

                                if (this.Editar(oDBconnection, oItem) == 0)
                                    throw (new Exception("Registro (" + oItem.ID + ") não existe."));
                            }
                            else if (oItem.Acao == "REMOVER")
                            {
                                if (this.Remover(oDBconnection, oItem, sUsuario) == 0)
                                    throw (new Exception("Registro (" + oItem.ID + ") não existe."));
                            }
                            else if (!string.IsNullOrWhiteSpace(oItem.Acao))
                            {
                                throw (new Exception("Ação (" + oItem.Acao + ") não permitida."));
                            }

                            nRegistro++;
                        }

                        sqoClassBiblioDB.Commit(oDBconnection);
                    }
                    catch (Exception ex)
                    {
                        sqoClassBiblioDB.Rollback(oDBconnection);

                        if (nRegistro != -1)
                            throw (new Exception("Registro " + nRegistro + " com problema!" + System.Environment.NewLine + System.Environment.NewLine + ex.Message));
                        else
                            throw (ex);
                    }

                    oClassMessage.Message = "Importação realizada com sucesso.";
                    oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.OK;
                    oClassMessage.MessageDescription = "";
                    oClassMessage.Ok = true;
                }
                else
                {
                    oDBconnection.Open();

                    sXmlDados = sXmlDados.Replace("null", "");
                    sqoClassPcpDynCriteriaItem oItem = null;

                    try
                    {
                        oItem = sqoClassBiblioSerDes.DeserializeObject<sqoClassPcpDynCriteriaItem>(sXmlDados);

                        oClassMessage.Ok = true;
                    }
                    catch (Exception ex)
                    {
                        oClassMessage.Message = "Erro no cadastro!";
                        oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.ERROR;
                        oClassMessage.MessageDescription = "Não foi possível deserializar o objeto enviado para a template.";
                        oClassMessage.Ok = false;
                    }

                    if (oClassMessage.Ok && !String.IsNullOrEmpty(sAction))
                    {
                        if (sAction == "Adicionar")
                        {
                            ValidaPersistencia(oDBconnection, oItem, sAction);

                            try
                            {
                                this.Adicionar(oDBconnection, oItem, sUsuario);

                                oClassMessage.Message = "Novo registro cadastrado com sucesso.";
                                oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.OK;
                                oClassMessage.MessageDescription = "";
                                oClassMessage.Ok = true;
                            }
                            catch (Exception ex)
                            {
                                oClassMessage.Message = "Não foi possível cadastrar novo registro!";
                                oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.ALERT;
                                oClassMessage.MessageDescription = ex.Message;
                                oClassMessage.Ok = false;
                            }
                        }
                        else if (sAction == "Duplicar")
                        {
                            ValidaPersistencia(oDBconnection, oItem, sAction);

                            try
                            {
                                if (oItem.File.Length == 0)
                                    oItem.File = GetFile(oDBconnection, oItem.ID);

                                this.Adicionar(oDBconnection, oItem, sUsuario);

                                oClassMessage.Message = "Novo registro cadastrado com sucesso.";
                                oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.OK;
                                oClassMessage.MessageDescription = "";
                                oClassMessage.Ok = true;
                            }
                            catch (Exception ex)
                            {
                                oClassMessage.Message = "Não foi possível cadastrar novo registro!";
                                oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.ALERT;
                                oClassMessage.MessageDescription = ex.Message;
                                oClassMessage.Ok = false;
                            }
                        }
                        else if (sAction == "Editar")
                        {
                            ValidaPersistencia(oDBconnection, oItem, sAction);

                            try
                            {
                                if (this.Editar(oDBconnection, oItem) == 0)
                                    throw (new Exception("Registro não encontrado."));

                                oClassMessage.Message = "Registro editado com sucesso.";
                                oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.OK;
                                oClassMessage.MessageDescription = "";
                                oClassMessage.Ok = true;
                            }
                            catch (Exception ex)
                            {
                                oClassMessage.Message = "Não foi possível editar o registro!";
                                oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.ERROR;
                                oClassMessage.MessageDescription = ex.Message;
                                oClassMessage.Ok = false;
                            }
                        }
                        else if (sAction == "Remover")
                        {
                            try
                            {
                                if (this.Remover(oDBconnection, oItem, sUsuario) == 0)
                                    throw (new Exception("Registro não encontrado."));

                                oClassMessage.Message = "Registro removido com sucesso.";
                                oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.OK;
                                oClassMessage.MessageDescription = "";
                                oClassMessage.Ok = true;
                            }
                            catch (Exception ex)
                            {
                                oClassMessage.Message = "Não foi possível remover o registro!";
                                oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.ERROR;
                                oClassMessage.MessageDescription = ex.Message;
                                oClassMessage.Ok = false;
                            }
                        }
                        else if (sAction == "DonwloadImagem")
                        {
                            try
                            {
                                byte[] oImagem = GetFile(oDBconnection, oItem.ID);

                                if (oImagem == null || oImagem.Length == 0)
                                    throw (new Exception("Imagem não encontrada ou não cadastrada."));

                                oClassMessage.Dado = Tools.SaveFileToDownload(oImagem, "png");
                                oClassMessage.Message = "Download da imagem realizado com sucesso.";
                                oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.OK;
                                oClassMessage.MessageDescription = "";
                                oClassMessage.Ok = true;
                            }
                            catch (Exception ex)
                            {
                                oClassMessage.Message = "Não foi possível fazer download da imagem!";
                                oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.ERROR;
                                oClassMessage.MessageDescription = ex.Message;
                                oClassMessage.Ok = false;
                            }
                        }
                        else if (sAction == "Sublist")
                        {
                            if (oListaParametrosMovimentacao != null && oListaParametrosMovimentacao.Count >= 2)
                            {
                                string subAction = oListaParametrosMovimentacao[0].Valor;

                                if (subAction == "Add")
                                {
                                    sqoClassPcpDynCriteriaSubItemDados dados = sqoClassBiblioSerDes.DeserializeObject<sqoClassPcpDynCriteriaSubItemDados>(oListaParametrosMovimentacao[1].Valor);

                                    ValidaSubPersistencia(oDBconnection, oItem, sAction, subAction, dados);

                                    this.AdicionarSubItem(oDBconnection, oItem.ID, dados.DadosAcao);

                                    dados.List.Add(new sqoClassPcpDynCriteriaSubItemDadosList() { Index = dados.List.Count, LISTA = dados.DadosAcao.LISTA, TEXTO = dados.DadosAcao.TEXTO, NUMERO = dados.DadosAcao.NUMERO });

                                    oListaParametrosMovimentacao[1].Valor = sqoClassBiblioSerDes.SerializeObject(dados).Replace("﻿<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");

                                    oClassMessage.Message = "Registro inserido com sucesso.";
                                    oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.OK;
                                    oClassMessage.MessageDescription = "";
                                    oClassMessage.Ok = true;
                                    oClassMessage.Dado = oListaParametrosMovimentacao;
                                }
                                else if (oListaParametrosMovimentacao[0].Valor == "Remove")
                                {
                                    int index = int.Parse(oListaParametrosMovimentacao[1].Valor);
                                    sqoClassPcpDynCriteriaSubItemDados dados = sqoClassBiblioSerDes.DeserializeObject<sqoClassPcpDynCriteriaSubItemDados>(oListaParametrosMovimentacao[2].Valor);

                                    if (this.RemoverSubItem(oDBconnection, oItem.ID, dados.List[index]) == 0)
                                        throw (new Exception("Registro não encontrado."));

                                    dados.List.RemoveAll(x => x.Index == index);

                                    oListaParametrosMovimentacao[2].Valor = sqoClassBiblioSerDes.SerializeObject(dados).Replace("﻿<?xml version=\"1.0\" encoding=\"utf-8\"?>", "");

                                    oClassMessage.Message = "Registro removidos com sucesso.";
                                    oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.OK;
                                    oClassMessage.MessageDescription = "";
                                    oClassMessage.Ok = true;
                                    oClassMessage.Dado = oListaParametrosMovimentacao;
                                }
                                //else if (oListaParametrosMovimentacao[0].Valor == "Edit")
                                //{
                                //
                                //}
                                else
                                {
                                    oClassMessage.Message = "Ação não suportada!";
                                    oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.ERROR;
                                    oClassMessage.MessageDescription = "";
                                    oClassMessage.Ok = false;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oClassMessage.Message = "Erro ao realizar ação!";
                oClassMessage.MessageType = sqoClassMessage.MessageTypeEnum.ERROR;
                oClassMessage.MessageDescription = ex.Message;
                oClassMessage.Ok = false;
            }
            finally
            {
                if (oDBconnection != null)
                {
                    if (oDBconnection.State == ConnectionState.Open)
                        oDBconnection.Close();
                    oDBconnection.Dispose();
                }
            }

            return oClassMessage;
        }


        private void Remover(sqoClassPcpDynCriteriaItem oPersistencia, string sUsuario)
        {

        }

        private void Editar(sqoClassPcpDynCriteriaItem oPersistencia)
        {
            
        }

        private void ValidaPersistencia(OleDbConnection oDBconnection, sqoClassPcpDynCriteriaItem oPersistencia, string sAcao)
        {
            if (string.IsNullOrEmpty(oPersistencia.AreaTexto))
                throw (new Exception("Texto área não especificado."));
            else if (oPersistencia.AreaTexto.Length > 500)
                throw (new Exception("Texto área não pode exceder 500 caracteres."));
            else if (oPersistencia.Data == DateTime.MinValue)
                throw (new Exception("Data deve ser especificada."));
            else if (oPersistencia.DataHora == DateTime.MinValue)
                throw (new Exception("Data Hora deve ser especificada."));
            else if (oPersistencia.Numero == -1)
                throw (new Exception("Número deve ser especificado."));
            else if (string.IsNullOrEmpty(oPersistencia.Texto))
                throw (new Exception("Texto deve ser especificada."));
            else if (oPersistencia.Texto.Length > 50)
                throw (new Exception("Texto não pode exceder 50 caracteres."));
            else if (sAcao == "Adicionar" && oPersistencia.File.Length == 0)
                throw (new Exception("Arquivo não especificado."));

        }

        private void Adicionar(sqoClassPcpDynCriteriaItem oPersistencia, string sUsuario)
        {
            
        }

        public void GetParametrosListagem(List<sqoClassParametrosEstrutura> oListaParametrosMovimentacao)
        {
            foreach (sqoClassParametrosEstrutura oClassParametrosEstrutura in oListaParametrosMovimentacao)
            {
                switch (oClassParametrosEstrutura.Campo)
                {
                    case "CRT_Texto": this.sParamListagem_CRT_Texto = oClassParametrosEstrutura.Valor; break;
                }
            }
        }

    }
}
